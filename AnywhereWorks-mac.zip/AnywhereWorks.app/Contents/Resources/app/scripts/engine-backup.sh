# Thread should become a Daemon.
# param1, appNameToQuit : to quit
# param2, sourcePath : path info
# param3, destionationPath : Destionation path where to place
# Last step open destionationPath app

# @author : SBTeam
#  
# Node-webkit Updater, calls the shell in mac,
# for replacing the exisiting app for the users
# var replacer = require('child_process').exec('sh appReplaceScript.sh '+process.pid+' '+<appPathToCopy>+' '+<olderAppPath>+' '+<appName>);
# 

# Usage : Replaces the old engine, with newer engine
# >> ~/Desktop/AnywhereWorks-logs.log 2>&1;
#!/bin/sh
echo "=== AnyWhereWorks ===" >> ~/Desktop/AnywhereWorks-logs.log;
echo "Daemon process -============================" >> ~/Desktop/AnywhereWorks-logs.log;

appNameToQuit=$1;
sourcePath=$2;
destionationPath=$3;
currentAppPath=$4;

# echo "========== Phase1: Printing Variables============================ ============ " >> ~/Desktop/AnywhereWorks-logs.log;
echo $appNameToQuit  >> ~/Desktop/AnywhereWorks-logs.log;
echo $sourcePath >> ~/Desktop/AnywhereWorks-logs.log; 
echo $destionationPath >> ~/Desktop/AnywhereWorks-logs.log;
echo "========== Phase1: Printing Variables End ============ " >> ~/Desktop/AnywhereWorks-logs.log;

echo "Step1: ================================">> ~/Desktop/AnywhereWorks-logs.log;
echo "Killing app : $appNameToQuit">> ~/Desktop/AnywhereWorks-logs.log;
killall -9 "$appNameToQuit" >> ~/Desktop/AnywhereWorks-logs.log 2>&1;
sleep 2 >> ~/Desktop/AnywhereWorks-logs.log 2>&1; # Wait the execution process for 2 seconds.


if [ -a "$currentAppPath" ]
then 
	echo "Step2: ================================">> ~/Desktop/AnywhereWorks-logs.log;
	echo "moving source to trash  : $currentAppPath">> ~/Desktop/AnywhereWorks-logs.log;
	mv "$currentAppPath" ~/.Trash/ >> ~/Desktop/AnywhereWorks-logs.log 2>&1;
else
	echo "$currentAppPath not available." >> ~/Desktop/AnywhereWorks-logs.log
fi


if [ -a "$destionationPath" ]
then 
	echo "Step3: ================================">> ~/Desktop/AnywhereWorks-logs.log;
	echo "Rename existing app : $destionationPath">> ~/Desktop/AnywhereWorks-logs.log;
	mv "$destionationPath" ~/.Trash/ >> ~/Desktop/AnywhereWorks-logs.log 2>&1;
else
	echo "$destionationPath not available." >> ~/Desktop/AnywhereWorks-logs.log
fi

echo "Step4: ================================">> ~/Desktop/AnywhereWorks-logs.log;
echo "Moving src[$sourcePath] to destination[$destionationPath] " >> ~/Desktop/AnywhereWorks-logs.log 2>&1;
mv -f "$sourcePath" "$destionationPath" >> ~/Desktop/AnywhereWorks-logs.log 2>&1;

echo "Step4: ================================">> ~/Desktop/AnywhereWorks-logs.log;
echo "opening updated application[$destionationPath]">> ~/Desktop/AnywhereWorks-logs.log;
open -nF "$destionationPath"

echo "Dameon process - stop" >> ~/Desktop/AnywhereWorks-logs.log;