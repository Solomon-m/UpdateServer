# Thread should become a Daemon.
# param1, appNameToQuit : to quit
# param2, sourcePath : path info
# param3, destionationPath : Destionation path where to place
# Last step open destionationPath app

# @author : SBTeam
#  
# Node-webkit Updater, calls the shell in mac,
# for replacing the exisiting app for the users
# var replacer = require('child_process').exec('sh appReplaceScript.sh '+process.pid+' '+<appPathToCopy>+' '+<olderAppPath>+' '+<appName>);
# 

# Usage : Replaces the old engine, with newer engine
# >> ~/Desktop/AnywhereWorks-logs.log 2>&1;
#!/bin/sh
echo "=== AnyWhereWorks === Updation starts" >> ~/Desktop/AnywhereWorks-logs.log;
echo "Daemon process -============================" >> ~/Desktop/AnywhereWorks-logs.log;

appNameToQuit=$1;
sourcePath=$2;
destionationPath=$3;
currentAppPath=$4;

# echo "========== Phase1: Printing Variables============================ ============ " >> ~/Desktop/AnywhereWorks-logs.log;
echo $appNameToQuit  >> ~/Desktop/AnywhereWorks-logs.log;
echo $sourcePath >> ~/Desktop/AnywhereWorks-logs.log; 
echo $destionationPath >> ~/Desktop/AnywhereWorks-logs.log;
echo "========== Phase1: Printing Variables End ============ " >> ~/Desktop/AnywhereWorks-logs.log;

echo "Step1: ================================">> ~/Desktop/AnywhereWorks-logs.log;
echo "Killing app : $appNameToQuit">> ~/Desktop/AnywhereWorks-logs.log;
killall -9 "$appNameToQuit" >> ~/Desktop/AnywhereWorks-logs.log 2>&1;
sleep 2 >> ~/Desktop/AnywhereWorks-logs.log 2>&1; # Wait the execution process for 2 seconds.

echo "Step2: ================================">> ~/Desktop/AnywhereWorks-logs.log;
if [ -a "$currentAppPath" ]
then 
	echo "Removing the app in path : $currentAppPath">> ~/Desktop/AnywhereWorks-logs.log;
	# mv "$currentAppPath" ~/.Trash/ >> ~/Desktop/AnywhereWorks-logs.log 2>&1;
	rm -rf "$currentAppPath" >> ~/Desktop/AnywhereWorks-logs.log 2>&1;
else
	echo "currentAppPath[$currentAppPath] not available." >> ~/Desktop/AnywhereWorks-logs.log
fi

echo "Step3: ================================">> ~/Desktop/AnywhereWorks-logs.log;
if [ -a "$destionationPath" ]
then 
	echo "Removing the destionation app in path : $destionationPath">> ~/Desktop/AnywhereWorks-logs.log;
	# mv "$destionationPath" ~/.Trash/ >> ~/Desktop/AnywhereWorks-logs.log 2>&1;
	rm -rf "$destionationPath" >> ~/Desktop/AnywhereWorks-logs.log 2>&1;
else
	echo "destinationPath[$destionationPath] not available." >> ~/Desktop/AnywhereWorks-logs.log
fi

echo "Step4: ================================">> ~/Desktop/AnywhereWorks-logs.log;
echo "Moving src[$sourcePath] to destination[$destionationPath] " >> ~/Desktop/AnywhereWorks-logs.log 2>&1;
mv -f "$sourcePath" "$destionationPath" >> ~/Desktop/AnywhereWorks-logs.log 2>&1;


echo "Step5: ================================">> ~/Desktop/AnywhereWorks-logs.log;
echo "opening updated application[$destionationPath]">> ~/Desktop/AnywhereWorks-logs.log;
open -nF "$destionationPath"

echo "Daemon process - stop" >> ~/Desktop/AnywhereWorks-logs.log;