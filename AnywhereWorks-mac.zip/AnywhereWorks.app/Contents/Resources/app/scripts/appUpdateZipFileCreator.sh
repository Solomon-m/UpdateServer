echo $1 # Directory path
echo `pwd`
zip -r Archive *

mv `pwd`/Archive.zip "$2"