#!/bin/bash
$1
$2
#echo "Url : $1 ">> ~/Desktop/Anyw.log
#echo "Browser : $2">> ~/Desktop/Anyw.log

if [ "$2" == "Chrome" ] ; then
	/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome "$1" --incognito
	osascript -e 'tell application "Google Chrome" to activate'
fi

#if [ "$2" == "Firefox" ] ; then
#	/Applications/Firefox.app/Contents/MacOS/firefox -Private-window "$1"
#fi