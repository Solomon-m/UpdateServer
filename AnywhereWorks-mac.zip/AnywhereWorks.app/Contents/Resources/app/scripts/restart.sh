processId=$1;
appToOpen=$2;

echo "$3";
echo "$appToOpen";

killall -9 "$3"; #app Name will come here ex : "Electron"
open -nF "$appToOpen";